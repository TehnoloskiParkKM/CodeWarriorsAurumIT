package com.snapit.milosvuckovic.splashscreenv2;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
//import android.support.design.widget.Snackbar;
import android.net.ConnectivityManager;
import android.support.v4.content.LocalBroadcastManager;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.snapit.milosvuckovic.splashscreenv2.receiver.NetworkStateChangeReceiver;

import static com.snapit.milosvuckovic.splashscreenv2.receiver.NetworkStateChangeReceiver.IS_NETWORK_AVAILABLE;

public class Screen2 extends AppCompatActivity {
Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screen2);

        //Novi toolbar sa logom u centru
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle("");
        setSupportActionBar(toolbar);
        btn = (Button)findViewById(R.id.posalji_btn);

        //Prelazak na Screen 3
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText unosKoda = (EditText) findViewById(R.id.unesi_kod_polje);

                if (unosKoda.getText().toString().trim().equals("probazademo")){

                    Intent intent = new Intent(Screen2.this, Screen3.class);
                    startActivity(intent);
                } else {
                    unosKoda.setError("Uneli ste pogrešan verifikacioni kod!");
                }

            }
        });

        //Obaveštenje o statusu internet konekcije
        IntentFilter intentFilter = new IntentFilter(NetworkStateChangeReceiver.NETWORK_AVAILABLE_ACTION);
        LocalBroadcastManager.getInstance(this).registerReceiver(new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                boolean isNetworkAvailable = intent.getBooleanExtra(IS_NETWORK_AVAILABLE, false);
                String networkStatus = isNetworkAvailable ? "uključena" : "isključena";

                Toast.makeText(Screen2.this, "Internet konekcija: " + networkStatus, Toast.LENGTH_LONG).show();
            }
        }, intentFilter);


    }
}
